import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'user_data_service.dart';
// Eliminamos la importación de home_page.dart ya que no se usa directamente aquí
import 'two_factor_auth_page.dart'; // Importa la nueva página

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String _errorMessage = '';
  bool _isLoading = false;

  Future<void> signInAndLoadData() async {
    if (_isLoading) return;
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });
    try {
      final userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
      final user = userCredential.user;
      if (user == null) {
        throw Exception('No se pudo obtener el usuario.');
      }

      // NO cargamos todos los datos de la compañía aquí.
      // Solo verificamos si el usuario tiene un companyId para continuar.
      final userDocRef = FirebaseFirestore.instance.collection('users').doc(user.uid);
      final userDoc = await userDocRef.get();

      if (!userDoc.exists) {
        throw 'Usuario no registrado por el administrador.';
      }

      final userData = userDoc.data()!;
      final companyId = userData['companyId'] as String?;

      if (companyId == null || companyId.isEmpty) {
        throw 'Usuario no asociado a ninguna compañía.';
      }

      // Redirigir a la página de verificación de 2FA
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => TwoFactorAuthPage(user: user)),
        );
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found' || e.code == 'wrong-password') {
        setState(() {
          _errorMessage = 'Email o contraseña incorrectos.';
        });
      } else {
        setState(() {
          _errorMessage = e.message ?? 'Ocurrió un error de autenticación.';
        });
      }
    } catch (e) {
      // Si hay un error, cerrar sesión y limpiar datos
      await FirebaseAuth.instance.signOut();
      UserDataService().clear();
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Spacer(flex: 2),
              Image.asset(AppTheme.logoAsset, height: 80),
              const SizedBox(height: 60.0),
              TextField(
                controller: _emailController,
                decoration: const InputDecoration(
                  labelText: 'Correo Electrónico',
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _passwordController,
                decoration: const InputDecoration(
                  labelText: 'Contraseña',
                ),
                obscureText: true,
              ),
              const SizedBox(height: 24.0),
              if (_errorMessage.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(_errorMessage, style: const TextStyle(color: Colors.red, fontSize: 14.0), textAlign: TextAlign.center),
                ),
              SizedBox(
                width: double.infinity,
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : ElevatedButton(
                        onPressed: signInAndLoadData,
                        child: const Text('Entrar'),
                      ),
              ),
              const Spacer(flex: 3),
              const Padding(
                padding: EdgeInsets.only(bottom: 24.0),
                child: Text(
                  'Diseñado por Foxbyte',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}